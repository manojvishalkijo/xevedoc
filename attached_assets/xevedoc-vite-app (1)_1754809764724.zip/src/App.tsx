"use client"

import type React from "react"

import { useState, useCallback, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Upload,
  FileText,
  Brain,
  Download,
  History,
  Settings,
  Eye,
  Tag,
  Sparkles,
  BarChart3,
  Plus,
  X,
  CheckCircle2,
  Clock,
  Play,
  RefreshCw,
  TrendingUp,
  HelpCircle,
  Star,
  Award,
  Lightbulb,
  ArrowRight,
  BookOpen,
  Rocket,
  Gift,
} from "lucide-react"
import { Button } from "./components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card"
import { Badge } from "./components/ui/badge"
import { Progress } from "./components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs"
import { Input } from "./components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./components/ui/dialog"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./components/ui/tooltip"
import { Toaster, toast } from "sonner"

function App() {
  const [activeTab, setActiveTab] = useState("overview")
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [showWelcome, setShowWelcome] = useState(true)
  const [showTutorial, setShowTutorial] = useState(false)
  const [showHelpPanel, setShowHelpPanel] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [showSuccessAnimation, setShowSuccessAnimation] = useState(false)
  const [tutorialStep, setTutorialStep] = useState(0)
  const [showFloatingHelp, setShowFloatingHelp] = useState(true)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const tutorialSteps = [
    {
      title: "Welcome to XeveDoc!",
      content: "Let's take a quick tour of your AI document analyzer.",
      target: "overview",
      icon: <Rocket className="w-6 h-6" />,
    },
    {
      title: "Upload Documents",
      content: "Drag and drop your files here or click to browse. We support PDFs, images, and more!",
      target: "upload",
      icon: <Upload className="w-6 h-6" />,
    },
    {
      title: "Watch the Magic",
      content: "Our AI processes your documents in real-time with OCR and NLP technology.",
      target: "processing",
      icon: <Brain className="w-6 h-6" />,
    },
    {
      title: "Get Insights",
      content: "View extracted data, smart tags, and AI summaries of your documents.",
      target: "results",
      icon: <BarChart3 className="w-6 h-6" />,
    },
  ]

  const processingSteps = [
    { name: "OCR Processing", progress: 100, status: "completed" },
    { name: "NLP Analysis", progress: 75, status: "processing" },
    { name: "Data Extraction", progress: 30, status: "pending" },
    { name: "Summarization", progress: 0, status: "pending" },
  ]

  const supportedFormats = [
    { name: "PDF", icon: <FileText className="w-6 h-6" />, color: "text-red-400" },
    { name: "DOCX", icon: <FileText className="w-6 h-6" />, color: "text-blue-400" },
    { name: "XLSX", icon: <FileText className="w-6 h-6" />, color: "text-green-400" },
    { name: "JPG", icon: <FileText className="w-6 h-6" />, color: "text-yellow-400" },
    { name: "PNG", icon: <FileText className="w-6 h-6" />, color: "text-purple-400" },
  ]

  const mockExtractedData = [
    { field: "Name", value: "John Smith", confidence: 98, type: "Person" },
    { field: "Email", value: "john.smith@company.com", confidence: 95, type: "Contact" },
    { field: "Amount", value: "$1,247.50", confidence: 99, type: "Financial" },
    { field: "Date", value: "2024-03-15", confidence: 92, type: "Date" },
    { field: "Company", value: "TechCorp Solutions", confidence: 97, type: "Organization" },
  ]

  const mockDocumentHistory = [
    { id: 1, name: "Invoice_2024_001.pdf", type: "Invoice", date: "2024-03-15", status: "Processed", accuracy: 98 },
    { id: 2, name: "Resume_JohnDoe.docx", type: "Resume", date: "2024-03-14", status: "Processed", accuracy: 96 },
    { id: 3, name: "Contract_ABC.pdf", type: "Legal", date: "2024-03-13", status: "Processing", accuracy: 0 },
    { id: 4, name: "Report_Q1.xlsx", type: "Report", date: "2024-03-12", status: "Processed", accuracy: 94 },
  ]

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragActive(false)
    const files = Array.from(e.dataTransfer.files)
    setUploadedFiles((prev) => [...prev, ...files])
    setShowSuccessAnimation(true)
    toast.success(`${files.length} file(s) uploaded successfully! 🎉`)
    setTimeout(() => setShowSuccessAnimation(false), 2000)
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragActive(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragActive(false)
  }, [])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setUploadedFiles((prev) => [...prev, ...files])
    setShowSuccessAnimation(true)
    toast.success(`${files.length} file(s) selected! ✨`)
    setTimeout(() => setShowSuccessAnimation(false), 2000)
  }, [])

  const startProcessing = () => {
    setIsProcessing(true)
    toast.info("Starting AI analysis... 🤖")
    setTimeout(() => {
      setIsProcessing(false)
      toast.success("Document analysis completed! 🎯")
    }, 5000)
  }

  const startTutorial = () => {
    setTutorialStep(0)
    setShowTutorial(true)
    setShowWelcome(false)
  }

  const nextTutorialStep = () => {
    if (tutorialStep < tutorialSteps.length - 1) {
      const nextStep = tutorialStep + 1
      setTutorialStep(nextStep)
      setActiveTab(tutorialSteps[nextStep].target)
    } else {
      setShowTutorial(false)
      setShowFloatingHelp(true)
      toast.success("Tutorial completed! You're ready to go! 🚀")
    }
  }

  const skipTutorial = () => {
    setShowTutorial(false)
    setShowWelcome(false)
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background text-foreground relative">
        <Toaster position="top-right" richColors />

        {/* Animated Background Effects */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <motion.div
            className="absolute top-20 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute bottom-20 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"
            animate={{
              scale: [1.2, 1, 1.2],
              opacity: [0.5, 0.3, 0.5],
            }}
            transition={{
              duration: 10,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
        </div>

        {/* Welcome Dialog */}
        <AnimatePresence>
          {showWelcome && (
            <Dialog open={showWelcome} onOpenChange={setShowWelcome}>
              <DialogContent className="sm:max-w-md">
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.9, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  <DialogHeader className="text-center">
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                      className="w-12 h-12 mx-auto mb-3 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center"
                    >
                      <Sparkles className="w-6 h-6 text-white" />
                    </motion.div>
                    <DialogTitle className="text-lg bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                      Welcome to XeveDoc! ✨
                    </DialogTitle>
                    <DialogDescription className="text-xs">
                      Your AI-powered document analyzer is ready to transform how you handle documents.
                    </DialogDescription>
                  </DialogHeader>

                  <div className="flex flex-col gap-2 mt-4">
                    <Button
                      onClick={startTutorial}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-xs h-8"
                    >
                      <BookOpen className="w-3 h-3 mr-2" />
                      Take a Quick Tour
                    </Button>
                    <Button variant="outline" onClick={() => setShowWelcome(false)} className="text-xs h-8">
                      <Rocket className="w-3 h-3 mr-2" />
                      Jump Right In
                    </Button>
                  </div>
                </motion.div>
              </DialogContent>
            </Dialog>
          )}
        </AnimatePresence>

        {/* Tutorial Overlay */}
        <AnimatePresence>
          {showTutorial && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-card rounded-xl p-5 max-w-md w-full border border-border/50"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center text-white">
                    {tutorialSteps[tutorialStep].icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold">{tutorialSteps[tutorialStep].title}</h3>
                    <p className="text-xs text-muted-foreground">
                      Step {tutorialStep + 1} of {tutorialSteps.length}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
                  {tutorialSteps[tutorialStep].content}
                </p>

                <div className="flex items-center justify-between">
                  <Button variant="ghost" onClick={skipTutorial} className="text-xs h-8">
                    Skip Tour
                  </Button>
                  <Button variant="outline" onClick={nextTutorialStep} className="text-xs h-8 bg-transparent">
                    {tutorialStep < tutorialSteps.length - 1 ? "Next" : "Finish"}
                    <ArrowRight className="w-3 h-3 ml-1" />
                  </Button>
                </div>

                <div className="flex gap-1 mt-3">
                  {tutorialSteps.map((_, index) => (
                    <div
                      key={index}
                      className={`h-1 rounded-full flex-1 transition-colors ${
                        index <= tutorialStep ? "bg-purple-500" : "bg-muted"
                      }`}
                    />
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Help Button */}
        <AnimatePresence>
          {showFloatingHelp && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="fixed bottom-6 left-6 z-40"
            >
              <Tooltip>
                <TooltipTrigger asChild>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setShowHelpPanel(true)}
                    className="w-14 h-14 bg-gradient-to-br from-purple-600 to-blue-600 text-white rounded-full shadow-lg flex items-center justify-center hover:shadow-xl transition-shadow glow-purple"
                  >
                    <motion.div
                      animate={{ rotate: [0, 15, -15, 0] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                    >
                      <HelpCircle className="w-6 h-6" />
                    </motion.div>
                  </motion.button>
                </TooltipTrigger>
                <TooltipContent side="right">
                  <p>Need help? Click for assistance!</p>
                </TooltipContent>
              </Tooltip>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Success Animation Overlay */}
        <AnimatePresence>
          {showSuccessAnimation && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 pointer-events-none z-30 flex items-center justify-center"
            >
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                exit={{ scale: 0, rotate: 180 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-2xl"
              >
                <CheckCircle2 className="w-12 h-12 text-white" />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Header */}
        <motion.header
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="border-b border-border/50 bg-card/80 backdrop-blur-md sticky top-0 z-20"
        >
          <div className="max-w-7xl mx-auto px-4 py-3">
            <div className="flex items-center justify-between">
              <motion.div className="flex items-center gap-2" whileHover={{ scale: 1.02 }}>
                <motion.div
                  className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center"
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  <Sparkles className="w-4 h-4 text-white" />
                </motion.div>
                <div>
                  <h1 className="text-lg font-semibold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                    XeveDoc
                  </h1>
                  <p className="text-xs text-muted-foreground">AI Document Analyzer</p>
                </div>
              </motion.div>

              <div className="flex items-center gap-3">
                <motion.div whileHover={{ scale: 1.05 }}>
                  <Badge variant="secondary" className="px-2 py-1 text-xs">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    {mockDocumentHistory.length} Processed
                  </Badge>
                </motion.div>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        size="sm"
                        onClick={() => setActiveTab("upload")}
                        className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-xs px-3 py-1.5 h-8"
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Upload
                      </Button>
                    </motion.div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Upload documents instantly</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
          </div>
        </motion.header>

        <div className="max-w-7xl mx-auto px-4 py-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            {/* Navigation Tabs */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <TabsList className="grid w-full grid-cols-6 lg:w-fit lg:grid-cols-6 h-9">
                {[
                  { value: "overview", icon: <Eye className="w-3 h-3" />, label: "Overview" },
                  { value: "upload", icon: <Upload className="w-3 h-3" />, label: "Upload" },
                  { value: "processing", icon: <Brain className="w-3 h-3" />, label: "Process" },
                  { value: "results", icon: <BarChart3 className="w-3 h-3" />, label: "Results" },
                  { value: "history", icon: <History className="w-3 h-3" />, label: "History" },
                  { value: "settings", icon: <Settings className="w-3 h-3" />, label: "Settings" },
                ].map((tab) => (
                  <Tooltip key={tab.value}>
                    <TooltipTrigger asChild>
                      <TabsTrigger value={tab.value} className="flex items-center gap-1 relative text-xs px-2 py-1">
                        {tab.icon}
                        <span className="hidden sm:inline">{tab.label}</span>
                        {tab.value === "upload" && uploadedFiles.length > 0 && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center"
                          >
                            {uploadedFiles.length}
                          </motion.div>
                        )}
                      </TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">{tab.label} - Click to navigate</p>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </TabsList>
            </motion.div>

            {/* Overview Section */}
            <TabsContent value="overview" className="space-y-6">
              {/* Hero Banner */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center py-8 px-6 bg-gradient-to-br from-purple-900/20 to-blue-900/20 rounded-xl relative overflow-hidden"
              >
                <div className="relative z-10">
                  <motion.div
                    animate={{ y: [0, -5, 0] }}
                    transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                  >
                    <h2 className="text-2xl font-semibold mb-3 tracking-tight">Transform Documents into Insights</h2>
                  </motion.div>
                  <motion.p
                    className="text-sm text-muted-foreground mb-6 max-w-xl mx-auto leading-relaxed"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    Upload any document and watch our AI extract, categorize, and summarize key information in seconds
                  </motion.p>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 }}
                  >
                    <Button
                      onClick={() => setActiveTab("upload")}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-xs px-4 py-2 h-9"
                    >
                      <Upload className="w-3 h-3 mr-2" />
                      Upload & Analyze Now
                    </Button>
                  </motion.div>
                </div>
              </motion.div>

              {/* Feature Cards */}
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  {
                    icon: <Eye className="w-6 h-6" />,
                    title: "Extract",
                    desc: "OCR & data extraction",
                    color: "from-purple-500 to-blue-500",
                  },
                  {
                    icon: <Tag className="w-6 h-6" />,
                    title: "Categorize",
                    desc: "Smart document tagging",
                    color: "from-blue-500 to-indigo-500",
                  },
                  {
                    icon: <Sparkles className="w-6 h-6" />,
                    title: "Summarize",
                    desc: "AI-powered insights",
                    color: "from-indigo-500 to-purple-500",
                  },
                  {
                    icon: <Download className="w-6 h-6" />,
                    title: "Export",
                    desc: "Multiple format options",
                    color: "from-purple-500 to-pink-500",
                  },
                ].map((feature, index) => (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    className="group"
                  >
                    <Card className="text-center h-full bg-gradient-to-b from-card to-card/50 hover:from-purple-900/20 hover:to-blue-900/20 transition-all duration-300 border-border/50 hover:border-purple-500/50">
                      <CardHeader className="pb-3">
                        <motion.div
                          className={`w-12 h-12 mx-auto mb-3 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white`}
                          whileHover={{ rotate: 360 }}
                          transition={{ duration: 0.5 }}
                        >
                          {feature.icon}
                        </motion.div>
                        <CardTitle className="group-hover:text-purple-400 transition-colors text-base">
                          {feature.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <CardDescription className="text-center text-xs">{feature.desc}</CardDescription>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Supported Formats */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
                <Card>
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <FileText className="w-4 h-4" />
                      Supported Document Formats
                      <Badge variant="secondary" className="ml-auto text-xs">
                        <Star className="w-2 h-2 mr-1" />
                        50+ Formats
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-5 gap-3">
                      {supportedFormats.map((format, index) => (
                        <motion.div
                          key={format.name}
                          className="flex flex-col items-center gap-1 p-3 rounded-lg bg-muted/50 hover:bg-muted/80 transition-colors cursor-pointer"
                          whileHover={{ scale: 1.1, y: -3 }}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <div className={format.color}>{format.icon}</div>
                          <span className="text-xs font-medium">{format.name}</span>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Upload Section */}
            <TabsContent value="upload" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* File Upload */}
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <Upload className="w-4 h-4" />
                        Document Upload
                        <motion.div
                          animate={{ rotate: [0, 10, -10, 0] }}
                          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                        >
                          <Gift className="w-3 h-3 text-purple-400" />
                        </motion.div>
                      </CardTitle>
                      <CardDescription className="text-xs">
                        Drag & drop files or click to browse. Supports single and multiple files.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <motion.div
                        onDrop={handleDrop}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        className={`border-2 border-dashed rounded-lg p-6 text-center transition-all cursor-pointer ${
                          dragActive
                            ? "border-purple-500 bg-purple-500/10 scale-105"
                            : "border-border/50 hover:border-purple-500/50"
                        }`}
                        onClick={() => fileInputRef.current?.click()}
                        whileHover={{ scale: 1.02 }}
                      >
                        <motion.div
                          animate={{ y: dragActive ? -10 : 0 }}
                          transition={{ type: "spring", stiffness: 300 }}
                        >
                          <Upload
                            className={`w-10 h-10 mx-auto mb-3 transition-colors ${
                              dragActive ? "text-purple-400" : "text-muted-foreground"
                            }`}
                          />
                        </motion.div>
                        <p className="text-sm font-medium mb-1">
                          {dragActive ? "Drop files here! 🎯" : "Drop files here or click to browse"}
                        </p>
                        <p className="text-xs text-muted-foreground">Supports PDF, DOCX, XLSX, JPG, PNG</p>
                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          accept=".pdf,.docx,.xlsx,.jpg,.jpeg,.png"
                          onChange={handleFileSelect}
                          className="hidden"
                        />
                      </motion.div>

                      <AnimatePresence>
                        {uploadedFiles.length > 0 && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-4 space-y-2"
                          >
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-medium">Uploaded Files ({uploadedFiles.length})</h4>
                              <Badge variant="secondary" className="text-xs">
                                <CheckCircle2 className="w-2 h-2 mr-1" />
                                Ready
                              </Badge>
                            </div>
                            {uploadedFiles.map((file, index) => (
                              <motion.div
                                key={index}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className="flex items-center justify-between p-2 bg-muted/50 rounded-lg hover:bg-muted/80 transition-colors"
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="w-3 h-3 text-purple-400" />
                                  <span className="text-xs font-medium">{file.name}</span>
                                  <Badge variant="outline" className="text-xs px-1 py-0">
                                    {(file.size / 1024 / 1024).toFixed(1)} MB
                                  </Badge>
                                </div>
                                <motion.button
                                  whileHover={{ scale: 1.1 }}
                                  whileTap={{ scale: 0.9 }}
                                  onClick={() => setUploadedFiles((prev) => prev.filter((_, i) => i !== index))}
                                  className="p-1 hover:bg-destructive/20 rounded text-destructive"
                                >
                                  <X className="w-3 h-3" />
                                </motion.button>
                              </motion.div>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Processing Actions */}
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-base">Processing Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                            <Button
                              className="w-full text-xs h-9"
                              disabled={uploadedFiles.length === 0}
                              onClick={() => {
                                startProcessing()
                                setActiveTab("processing")
                              }}
                            >
                              <Play className="w-3 h-3 mr-2" />
                              Start AI Analysis ({uploadedFiles.length} files)
                              {uploadedFiles.length > 0 && (
                                <motion.div
                                  animate={{ rotate: 360 }}
                                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                                  className="ml-2"
                                >
                                  <Sparkles className="w-3 h-3" />
                                </motion.div>
                              )}
                            </Button>
                          </motion.div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs">Process all uploaded files with AI</p>
                        </TooltipContent>
                      </Tooltip>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>

            {/* Processing Dashboard */}
            <TabsContent value="processing" className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                {/* Document Preview */}
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-2">
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <Eye className="w-4 h-4" />
                        Document Preview
                        {isProcessing && (
                          <Badge variant="secondary" className="ml-auto text-xs">
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                            >
                              <RefreshCw className="w-2 h-2 mr-1" />
                            </motion.div>
                            Processing
                          </Badge>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-muted/50 rounded-lg p-6 text-center min-h-[300px] flex items-center justify-center">
                        <div className="space-y-3">
                          <motion.div
                            animate={isProcessing ? { scale: [1, 1.1, 1] } : {}}
                            transition={{ duration: 2, repeat: isProcessing ? Number.POSITIVE_INFINITY : 0 }}
                          >
                            <FileText className="w-12 h-12 mx-auto text-muted-foreground" />
                          </motion.div>
                          <div>
                            <p className="text-sm font-medium">Invoice_2024_001.pdf</p>
                            <p className="text-xs text-muted-foreground">2.4 MB • Page 1 of 3</p>
                          </div>
                          {isProcessing && (
                            <motion.div className="space-y-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                              <motion.div
                                className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full mx-auto"
                                animate={{ rotate: 360 }}
                                transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                              />
                              <motion.p
                                className="text-xs text-purple-400"
                                animate={{ opacity: [0.5, 1, 0.5] }}
                                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                              >
                                Analyzing document with AI...
                              </motion.p>
                            </motion.div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Processing Status */}
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <Brain className="w-4 h-4" />
                        AI Processing Status
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {processingSteps.map((step, index) => (
                        <motion.div
                          key={step.name}
                          className="space-y-2"
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium">{step.name}</span>
                            <motion.div
                              animate={step.status === "processing" ? { scale: [1, 1.2, 1] } : {}}
                              transition={{
                                duration: 1,
                                repeat: step.status === "processing" ? Number.POSITIVE_INFINITY : 0,
                              }}
                            >
                              {step.status === "completed" && <CheckCircle2 className="w-3 h-3 text-green-400" />}
                              {step.status === "processing" && (
                                <motion.div
                                  animate={{ rotate: 360 }}
                                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                                >
                                  <RefreshCw className="w-3 h-3 text-blue-400" />
                                </motion.div>
                              )}
                              {step.status === "pending" && <Clock className="w-3 h-3 text-muted-foreground" />}
                            </motion.div>
                          </div>
                          <Progress value={step.progress} className="h-1.5" />
                          <p className="text-xs text-muted-foreground">{step.progress}% complete</p>
                        </motion.div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>

            {/* Results Panel */}
            <TabsContent value="results" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Extracted Data */}
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <BarChart3 className="w-4 h-4" />
                        Extracted Data
                        <Badge variant="secondary" className="ml-auto text-xs">
                          <Award className="w-2 h-2 mr-1" />
                          {mockExtractedData.length} Fields
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {mockExtractedData.map((item, index) => (
                          <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                          >
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-medium">{item.field}</span>
                                <Badge variant="outline" className="text-xs px-1 py-0">
                                  {item.type}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground font-mono mt-1">{item.value}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Progress value={item.confidence} className="h-1.5 w-12" />
                              <span className="text-xs font-semibold text-green-400">{item.confidence}%</span>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* AI Summary */}
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <Sparkles className="w-4 h-4" />
                        AI Summary
                        <motion.div
                          animate={{ y: [0, -2, 0] }}
                          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                        >
                          <Lightbulb className="w-3 h-3 text-yellow-400" />
                        </motion.div>
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          Invoice
                        </Badge>
                        <Badge variant="outline" className="text-green-400 border-green-400 text-xs">
                          <CheckCircle2 className="w-2 h-2 mr-1" />
                          98% Confidence
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <motion.p
                        className="text-xs leading-relaxed text-muted-foreground"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.5 }}
                      >
                        This is an invoice from TechCorp Solutions dated March 15, 2024, for services totaling
                        $1,247.50. The invoice number is INV-2024-001 and includes contact information for John Smith.
                        Payment terms indicate net 30 days with a due date of April 14, 2024.
                      </motion.p>

                      <div className="mt-4">
                        <h4 className="text-xs font-medium mb-2">Smart Tags</h4>
                        <div className="flex flex-wrap gap-1">
                          {["Invoice", "Finance", "Q1-2024", "TechCorp", "Payment Due"].map((tag, index) => (
                            <motion.div
                              key={tag}
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: index * 0.1 }}
                              whileHover={{ scale: 1.1 }}
                            >
                              <Badge
                                variant="secondary"
                                className="cursor-pointer hover:bg-purple-500/20 text-xs px-2 py-0"
                              >
                                {tag}
                              </Badge>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Export Options */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                <Card>
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Download className="w-4 h-4" />
                      Export & Integration Options
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-3">
                      {[
                        { label: "Export to Excel", desc: "Download as .xlsx" },
                        { label: "Push to CRM", desc: "Sync with CRM system" },
                        { label: "Save to Database", desc: "Store in database" },
                      ].map((option, index) => (
                        <motion.div
                          key={option.label}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          whileHover={{ scale: 1.05 }}
                        >
                          <Button
                            variant={index === 0 ? "default" : "outline"}
                            className="flex flex-col items-center gap-2 h-auto py-4 w-full text-xs"
                          >
                            <Download className="w-4 h-4" />
                            <div className="text-center">
                              <span className="font-medium">{option.label}</span>
                              <p className="text-xs text-muted-foreground mt-1">{option.desc}</p>
                            </div>
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* History Section */}
            <TabsContent value="history" className="space-y-6">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card>
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <History className="w-4 h-4" />
                      Document History
                      <Badge variant="secondary" className="ml-auto text-xs">
                        {mockDocumentHistory.length} Documents
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <Input placeholder="Search documents..." className="max-w-sm text-xs h-8" />
                    </div>
                    <div className="space-y-3">
                      {mockDocumentHistory.map((doc, index) => (
                        <motion.div
                          key={doc.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <FileText className="w-4 h-4 text-purple-400" />
                            <div>
                              <p className="text-xs font-medium">{doc.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {doc.type} • {doc.date}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge variant={doc.status === "Processed" ? "default" : "secondary"} className="text-xs">
                              {doc.status}
                            </Badge>
                            {doc.accuracy > 0 && (
                              <div className="flex items-center gap-2">
                                <Progress value={doc.accuracy} className="h-1.5 w-12" />
                                <span className="text-xs">{doc.accuracy}%</span>
                              </div>
                            )}
                            <Button size="sm" variant="outline" className="h-7 w-7 p-0 bg-transparent">
                              <Eye className="w-3 h-3" />
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Settings Section */}
            <TabsContent value="settings" className="space-y-6">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card>
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Settings className="w-4 h-4" />
                      Application Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-sm font-medium mb-3">Processing Options</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-xs font-medium">Auto-categorize documents</p>
                              <p className="text-xs text-muted-foreground">Automatically tag document types</p>
                            </div>
                            <input type="checkbox" defaultChecked className="rounded" />
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-xs font-medium">Generate summaries</p>
                              <p className="text-xs text-muted-foreground">Create AI-powered summaries</p>
                            </div>
                            <input type="checkbox" defaultChecked className="rounded" />
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium mb-3">Integration Settings</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <p className="text-xs font-medium">Excel Template</p>
                              <p className="text-xs text-muted-foreground">Connected</p>
                            </div>
                            <Badge variant="default" className="text-xs">
                              Active
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <p className="text-xs font-medium">CRM Integration</p>
                              <p className="text-xs text-muted-foreground">Not configured</p>
                            </div>
                            <Button size="sm" variant="outline" className="text-xs h-7 px-3 bg-transparent">
                              Configure
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Help Panel */}
            <AnimatePresence>
              {showHelpPanel && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
                  onClick={() => setShowHelpPanel(false)}
                >
                  <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    onClick={(e) => e.stopPropagation()}
                    className="bg-card rounded-xl p-5 max-w-xl w-full max-h-[80vh] overflow-y-auto border border-border/50"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                          <HelpCircle className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <h3 className="text-base font-semibold">XeveDoc Help Center</h3>
                          <p className="text-xs text-muted-foreground">Get help and learn about features</p>
                        </div>
                      </div>
                      <Button variant="ghost" onClick={() => setShowHelpPanel(false)} className="h-8 w-8 p-0">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="space-y-3">
                      {[
                        {
                          title: "Getting Started",
                          description: "Learn the basics of document analysis",
                          icon: <BookOpen className="w-4 h-4" />,
                        },
                        {
                          title: "Upload Documents",
                          description: "How to upload and prepare your files",
                          icon: <Upload className="w-4 h-4" />,
                        },
                        {
                          title: "AI Processing",
                          description: "Understanding OCR and NLP analysis",
                          icon: <Brain className="w-4 h-4" />,
                        },
                        {
                          title: "Export & Integration",
                          description: "Export data and connect to other tools",
                          icon: <Download className="w-4 h-4" />,
                        },
                      ].map((item, index) => (
                        <motion.div
                          key={item.title}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="p-3 rounded-lg border border-border/50 hover:border-purple-500/50 cursor-pointer transition-colors"
                          whileHover={{ scale: 1.02 }}
                        >
                          <div className="flex items-center gap-3">
                            <div className="text-purple-400">{item.icon}</div>
                            <div>
                              <h4 className="text-xs font-medium">{item.title}</h4>
                              <p className="text-xs text-muted-foreground">{item.description}</p>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>

                    <div className="mt-4 pt-3 border-t border-border/50 text-center">
                      <Button onClick={startTutorial} variant="outline" className="text-xs h-8 bg-transparent">
                        <Play className="w-3 h-3 mr-2" />
                        Restart Tutorial
                      </Button>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </Tabs>
        </div>

        {/* Help Panel */}
        <AnimatePresence>
          {showHelpPanel && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
              onClick={() => setShowHelpPanel(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-card rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto border border-border/50"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
                      <HelpCircle className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold">XeveDoc Help Center</h3>
                      <p className="text-sm text-muted-foreground">Get help and learn about features</p>
                    </div>
                  </div>
                  <Button variant="ghost" onClick={() => setShowHelpPanel(false)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="space-y-4">
                  {[
                    {
                      title: "Getting Started",
                      description: "Learn the basics of document analysis",
                      icon: <BookOpen className="w-5 h-5" />,
                    },
                    {
                      title: "Upload Documents",
                      description: "How to upload and prepare your files",
                      icon: <Upload className="w-5 h-5" />,
                    },
                    {
                      title: "AI Processing",
                      description: "Understanding OCR and NLP analysis",
                      icon: <Brain className="w-5 h-5" />,
                    },
                    {
                      title: "Export & Integration",
                      description: "Export data and connect to other tools",
                      icon: <Download className="w-5 h-5" />,
                    },
                  ].map((item, index) => (
                    <motion.div
                      key={item.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 rounded-lg border border-border/50 hover:border-purple-500/50 cursor-pointer transition-colors"
                      whileHover={{ scale: 1.02 }}
                    >
                      <div className="flex items-center gap-3">
                        <div className="text-purple-400">{item.icon}</div>
                        <div>
                          <h4 className="font-medium">{item.title}</h4>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-6 pt-4 border-t border-border/50 text-center">
                  <Button onClick={startTutorial} variant="outline">
                    <Play className="w-4 h-4 mr-2" />
                    Restart Tutorial
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </TooltipProvider>
  )
}

export default App
