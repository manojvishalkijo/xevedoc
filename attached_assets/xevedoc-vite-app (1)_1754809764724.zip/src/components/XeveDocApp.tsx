"use client"

import type React from "react"

import { useState, useCallback, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Upload,
  FileText,
  Brain,
  Download,
  History,
  Settings,
  Cloud,
  Database,
  Eye,
  Tag,
  Sparkles,
  BarChart3,
  Users,
  FileSpreadsheet,
  Search,
  Filter,
  Plus,
  X,
  CheckCircle2,
  Clock,
  Play,
  Pause,
  RefreshCw,
  TrendingUp,
  Zap,
  Target,
  Shield,
  Globe,
  ImageIcon,
  HelpCircle,
  Star,
  Award,
  Lightbulb,
  ArrowRight,
  BookOpen,
  Rocket,
  Gift,
} from "lucide-react"
import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { Switch } from "./ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table"
import { ScrollArea } from "./ui/scroll-area"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip"
import { toast } from "sonner"

export function XeveDocApp() {
  const [activeTab, setActiveTab] = useState("overview")
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingStep, setProcessingStep] = useState(0)
  const [extractedData, setExtractedData] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [showWelcome, setShowWelcome] = useState(true)
  const [showTutorial, setShowTutorial] = useState(false)
  const [showHelpPanel, setShowHelpPanel] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [showSuccessAnimation, setShowSuccessAnimation] = useState(false)
  const [tutorialStep, setTutorialStep] = useState(0)
  const [showFloatingHelp, setShowFloatingHelp] = useState(true)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Tutorial steps
  const tutorialSteps = [
    {
      title: "Welcome to XeveDoc!",
      content: "Let's take a quick tour of your AI document analyzer.",
      target: "overview",
      icon: <Rocket className="w-6 h-6" />,
    },
    {
      title: "Upload Documents",
      content: "Drag and drop your files here or click to browse. We support PDFs, images, and more!",
      target: "upload",
      icon: <Upload className="w-6 h-6" />,
    },
    {
      title: "Watch the Magic",
      content: "Our AI processes your documents in real-time with OCR and NLP technology.",
      target: "processing",
      icon: <Brain className="w-6 h-6" />,
    },
    {
      title: "Get Insights",
      content: "View extracted data, smart tags, and AI summaries of your documents.",
      target: "results",
      icon: <BarChart3 className="w-6 h-6" />,
    },
  ]

  const processingSteps = [
    { name: "OCR Processing", progress: 100, status: "completed" },
    { name: "NLP Analysis", progress: 75, status: "processing" },
    { name: "Data Extraction", progress: 30, status: "pending" },
    { name: "Summarization", progress: 0, status: "pending" },
  ]

  const supportedFormats = [
    { name: "PDF", icon: <FileText className="w-6 h-6" />, color: "text-red-400" },
    { name: "DOCX", icon: <FileText className="w-6 h-6" />, color: "text-blue-400" },
    { name: "XLSX", icon: <FileSpreadsheet className="w-6 h-6" />, color: "text-green-400" },
    { name: "JPG", icon: <ImageIcon className="w-6 h-6" />, color: "text-yellow-400" },
    { name: "PNG", icon: <ImageIcon className="w-6 h-6" />, color: "text-purple-400" },
  ]

  const mockExtractedData = [
    { field: "Name", value: "John Smith", confidence: 98, type: "Person" },
    { field: "Email", value: "john.smith@company.com", confidence: 95, type: "Contact" },
    { field: "Amount", value: "$1,247.50", confidence: 99, type: "Financial" },
    { field: "Date", value: "2024-03-15", confidence: 92, type: "Date" },
    { field: "Company", value: "TechCorp Solutions", confidence: 97, type: "Organization" },
  ]

  const mockDocumentHistory = [
    { id: 1, name: "Invoice_2024_001.pdf", type: "Invoice", date: "2024-03-15", status: "Processed", accuracy: 98 },
    { id: 2, name: "Resume_JohnDoe.docx", type: "Resume", date: "2024-03-14", status: "Processed", accuracy: 96 },
    { id: 3, name: "Contract_ABC.pdf", type: "Legal", date: "2024-03-13", status: "Processing", accuracy: 0 },
    { id: 4, name: "Report_Q1.xlsx", type: "Report", date: "2024-03-12", status: "Processed", accuracy: 94 },
  ]

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragActive(false)
    const files = Array.from(e.dataTransfer.files)
    setUploadedFiles((prev) => [...prev, ...files])
    setShowSuccessAnimation(true)
    toast.success(`${files.length} file(s) uploaded successfully! 🎉`, {
      description: "Ready for AI analysis",
    })
    setTimeout(() => setShowSuccessAnimation(false), 2000)
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragActive(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragActive(false)
  }, [])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setUploadedFiles((prev) => [...prev, ...files])
    setShowSuccessAnimation(true)
    toast.success(`${files.length} file(s) selected! ✨`)
    setTimeout(() => setShowSuccessAnimation(false), 2000)
  }, [])

  const startProcessing = () => {
    setIsProcessing(true)
    setProcessingStep(0)
    toast.info("Starting AI analysis... 🤖")

    // Simulate processing steps with realistic timing
    const interval = setInterval(() => {
      setProcessingStep((prev) => {
        if (prev >= processingSteps.length - 1) {
          clearInterval(interval)
          setIsProcessing(false)
          setExtractedData(mockExtractedData)
          setShowSuccessAnimation(true)
          toast.success("Document analysis completed! 🎯", {
            description: "All insights extracted successfully",
          })
          setTimeout(() => setShowSuccessAnimation(false), 3000)
          return prev
        }
        return prev + 1
      })
    }, 2000)
  }

  const startTutorial = () => {
    setTutorialStep(0)
    setShowTutorial(true)
    setShowWelcome(false)
  }

  const nextTutorialStep = () => {
    if (tutorialStep < tutorialSteps.length - 1) {
      const nextStep = tutorialStep + 1
      setTutorialStep(nextStep)
      setActiveTab(tutorialSteps[nextStep].target)
    } else {
      setShowTutorial(false)
      setShowFloatingHelp(true)
      toast.success("Tutorial completed! You're ready to go! 🚀")
    }
  }

  const skipTutorial = () => {
    setShowTutorial(false)
    setShowWelcome(false)
  }

  // Auto-hide floating help after some time
  useEffect(() => {
    if (showFloatingHelp) {
      const timer = setTimeout(() => {
        setShowFloatingHelp(false)
      }, 10000)
      return () => clearTimeout(timer)
    }
  }, [showFloatingHelp])

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background text-foreground relative">
        {/* Animated Background Effects */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <motion.div
            className="absolute top-20 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute bottom-20 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"
            animate={{
              scale: [1.2, 1, 1.2],
              opacity: [0.5, 0.3, 0.5],
            }}
            transition={{
              duration: 10,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
        </div>

        {/* Welcome Dialog */}
        <AnimatePresence>
          {showWelcome && (
            <Dialog open={showWelcome} onOpenChange={setShowWelcome}>
              <DialogContent className="sm:max-w-md">
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.9, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  <DialogHeader className="text-center">
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                      className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center"
                    >
                      <Sparkles className="w-8 h-8 text-white" />
                    </motion.div>
                    <DialogTitle className="text-2xl bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                      Welcome to XeveDoc! ✨
                    </DialogTitle>
                    <DialogDescription className="text-base">
                      Your AI-powered document analyzer is ready to transform how you handle documents.
                    </DialogDescription>
                  </DialogHeader>

                  <div className="flex flex-col gap-3 mt-6">
                    <Button
                      onClick={startTutorial}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    >
                      <BookOpen className="w-4 h-4 mr-2" />
                      Take a Quick Tour
                    </Button>
                    <Button variant="outline" onClick={() => setShowWelcome(false)}>
                      <Rocket className="w-4 h-4 mr-2" />
                      Jump Right In
                    </Button>
                  </div>
                </motion.div>
              </DialogContent>
            </Dialog>
          )}
        </AnimatePresence>

        {/* Tutorial Overlay */}
        <AnimatePresence>
          {showTutorial && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-card rounded-2xl p-6 max-w-md w-full border border-border/50"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center text-white">
                    {tutorialSteps[tutorialStep].icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{tutorialSteps[tutorialStep].title}</h3>
                    <p className="text-sm text-muted-foreground">
                      Step {tutorialStep + 1} of {tutorialSteps.length}
                    </p>
                  </div>
                </div>

                <p className="text-muted-foreground mb-6">{tutorialSteps[tutorialStep].content}</p>

                <div className="flex items-center justify-between">
                  <Button variant="ghost" onClick={skipTutorial}>
                    Skip Tour
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={nextTutorialStep}>
                      {tutorialStep < tutorialSteps.length - 1 ? "Next" : "Finish"}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  {tutorialSteps.map((_, index) => (
                    <div
                      key={index}
                      className={`h-1 rounded-full flex-1 transition-colors ${
                        index <= tutorialStep ? "bg-purple-500" : "bg-muted"
                      }`}
                    />
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Help Button */}
        <AnimatePresence>
          {showFloatingHelp && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="fixed bottom-6 left-6 z-40"
            >
              <Tooltip>
                <TooltipTrigger asChild>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setShowHelpPanel(true)}
                    className="w-14 h-14 bg-gradient-to-br from-purple-600 to-blue-600 text-white rounded-full shadow-lg flex items-center justify-center hover:shadow-xl transition-shadow glow-purple"
                  >
                    <motion.div
                      animate={{ rotate: [0, 15, -15, 0] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                    >
                      <HelpCircle className="w-6 h-6" />
                    </motion.div>
                  </motion.button>
                </TooltipTrigger>
                <TooltipContent side="right">
                  <p>Need help? Click for assistance!</p>
                </TooltipContent>
              </Tooltip>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Success Animation Overlay */}
        <AnimatePresence>
          {showSuccessAnimation && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 pointer-events-none z-30 flex items-center justify-center"
            >
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                exit={{ scale: 0, rotate: 180 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="w-24 h-24 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-2xl"
              >
                <CheckCircle2 className="w-12 h-12 text-white" />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Header */}
        <motion.header
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="border-b border-border/50 bg-card/80 backdrop-blur-md sticky top-0 z-20"
        >
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <motion.div className="flex items-center gap-3" whileHover={{ scale: 1.02 }}>
                <motion.div
                  className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center"
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  <Sparkles className="w-6 h-6 text-white" />
                </motion.div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                    XeveDoc
                  </h1>
                  <p className="text-sm text-muted-foreground">AI Document Analyzer</p>
                </div>
              </motion.div>

              <div className="flex items-center gap-4">
                <motion.div whileHover={{ scale: 1.05 }}>
                  <Badge variant="secondary" className="px-3 py-1">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    {mockDocumentHistory.length} Documents Processed
                  </Badge>
                </motion.div>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        size="sm"
                        onClick={() => setActiveTab("upload")}
                        className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Quick Upload
                      </Button>
                    </motion.div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Upload documents instantly</p>
                  </TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button variant="outline" size="sm" onClick={() => setShowHelpPanel(true)}>
                        <HelpCircle className="w-4 h-4" />
                      </Button>
                    </motion.div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Get help and tips</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
          </div>
        </motion.header>

        <div className="max-w-7xl mx-auto px-4 py-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            {/* Enhanced Navigation Tabs */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <TabsList className="grid w-full grid-cols-6 lg:w-fit lg:grid-cols-6">
                {[
                  { value: "overview", icon: <Eye className="w-4 h-4" />, label: "Overview" },
                  { value: "upload", icon: <Upload className="w-4 h-4" />, label: "Upload" },
                  { value: "processing", icon: <Brain className="w-4 h-4" />, label: "Process" },
                  { value: "results", icon: <BarChart3 className="w-4 h-4" />, label: "Results" },
                  { value: "history", icon: <History className="w-4 h-4" />, label: "History" },
                  { value: "settings", icon: <Settings className="w-4 h-4" />, label: "Settings" },
                ].map((tab) => (
                  <Tooltip key={tab.value}>
                    <TooltipTrigger asChild>
                      <TabsTrigger value={tab.value} className="flex items-center gap-2 relative">
                        {tab.icon}
                        <span className="hidden sm:inline">{tab.label}</span>
                        {tab.value === "upload" && uploadedFiles.length > 0 && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center"
                          >
                            {uploadedFiles.length}
                          </motion.div>
                        )}
                      </TabsTrigger>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{tab.label} - Click to navigate</p>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </TabsList>
            </motion.div>

            {/* Overview Section - Enhanced */}
            <TabsContent value="overview" className="space-y-6">
              {/* Hero Banner with Enhanced Animation */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center py-12 px-6 bg-gradient-to-br from-purple-900/20 to-blue-900/20 rounded-2xl relative overflow-hidden"
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-blue-600/10"
                  animate={{
                    background: [
                      "linear-gradient(45deg, rgba(147, 51, 234, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%)",
                      "linear-gradient(225deg, rgba(147, 51, 234, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%)",
                      "linear-gradient(45deg, rgba(147, 51, 234, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%)",
                    ],
                  }}
                  transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY }}
                />
                <div className="relative z-10">
                  <motion.div
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                  >
                    <h2 className="text-4xl font-bold mb-4">Transform Documents into Insights</h2>
                  </motion.div>
                  <motion.p
                    className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    Upload any document and watch our AI extract, categorize, and summarize key information in seconds
                  </motion.p>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 }}
                  >
                    <Button
                      size="lg"
                      onClick={() => setActiveTab("upload")}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 relative overflow-hidden group"
                    >
                      <motion.div
                        className="absolute inset-0 bg-white/20"
                        initial={{ x: "-100%" }}
                        whileHover={{ x: "100%" }}
                        transition={{ duration: 0.5 }}
                      />
                      <Upload className="w-5 h-5 mr-2" />
                      Upload & Analyze Now
                    </Button>
                  </motion.div>
                </div>
              </motion.div>

              {/* Enhanced Feature Cards */}
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  {
                    icon: <Eye className="w-8 h-8" />,
                    title: "Extract",
                    desc: "OCR & data extraction",
                    color: "from-purple-500 to-blue-500",
                  },
                  {
                    icon: <Tag className="w-8 h-8" />,
                    title: "Categorize",
                    desc: "Smart document tagging",
                    color: "from-blue-500 to-indigo-500",
                  },
                  {
                    icon: <Sparkles className="w-8 h-8" />,
                    title: "Summarize",
                    desc: "AI-powered insights",
                    color: "from-indigo-500 to-purple-500",
                  },
                  {
                    icon: <Download className="w-8 h-8" />,
                    title: "Export",
                    desc: "Multiple format options",
                    color: "from-purple-500 to-pink-500",
                  },
                ].map((feature, index) => (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    className="group"
                  >
                    <Card className="text-center h-full bg-gradient-to-b from-card to-card/50 hover:from-purple-900/20 hover:to-blue-900/20 transition-all duration-300 border-border/50 hover:border-purple-500/50 relative overflow-hidden">
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity"
                        initial={false}
                      />
                      <CardHeader className="relative z-10">
                        <motion.div
                          className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-white`}
                          whileHover={{ rotate: 360 }}
                          transition={{ duration: 0.5 }}
                        >
                          {feature.icon}
                        </motion.div>
                        <CardTitle className="group-hover:text-purple-400 transition-colors">{feature.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-center">{feature.desc}</CardDescription>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Enhanced Supported Formats */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
                <Card className="relative overflow-hidden">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5" />
                      Supported Document Formats
                      <Badge variant="secondary" className="ml-auto">
                        <Star className="w-3 h-3 mr-1" />
                        50+ Formats
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-5 gap-4">
                      {supportedFormats.map((format, index) => (
                        <motion.div
                          key={format.name}
                          className="flex flex-col items-center gap-2 p-4 rounded-lg bg-muted/50 hover:bg-muted/80 transition-colors cursor-pointer"
                          whileHover={{ scale: 1.1, y: -5 }}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <div className={format.color}>{format.icon}</div>
                          <span className="text-sm font-medium">{format.name}</span>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Enhanced Upload Section */}
            <TabsContent value="upload" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Enhanced File Upload */}
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                  <Card className="relative overflow-hidden">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Upload className="w-5 h-5" />
                        Document Upload
                        <motion.div
                          animate={{ rotate: [0, 10, -10, 0] }}
                          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                        >
                          <Gift className="w-4 h-4 text-purple-400" />
                        </motion.div>
                      </CardTitle>
                      <CardDescription>
                        Drag & drop files or click to browse. Supports single and multiple files.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <motion.div
                        onDrop={handleDrop}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        className={`border-2 border-dashed rounded-lg p-8 text-center transition-all cursor-pointer relative overflow-hidden ${
                          dragActive
                            ? "border-purple-500 bg-purple-500/10 scale-105"
                            : "border-border/50 hover:border-purple-500/50"
                        }`}
                        onClick={() => fileInputRef.current?.click()}
                        whileHover={{ scale: 1.02 }}
                        animate={dragActive ? { scale: 1.05 } : { scale: 1 }}
                      >
                        <motion.div
                          animate={{ y: dragActive ? -10 : 0 }}
                          transition={{ type: "spring", stiffness: 300 }}
                        >
                          <Upload
                            className={`w-12 h-12 mx-auto mb-4 transition-colors ${
                              dragActive ? "text-purple-400" : "text-muted-foreground"
                            }`}
                          />
                        </motion.div>
                        <motion.p
                          className="text-lg font-medium mb-2"
                          animate={{ color: dragActive ? "#a855f7" : "#e2e8f0" }}
                        >
                          {dragActive ? "Drop files here! 🎯" : "Drop files here or click to browse"}
                        </motion.p>
                        <p className="text-sm text-muted-foreground">Supports PDF, DOCX, XLSX, JPG, PNG</p>
                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          accept=".pdf,.docx,.xlsx,.jpg,.jpeg,.png"
                          onChange={handleFileSelect}
                          className="hidden"
                        />
                      </motion.div>

                      <AnimatePresence>
                        {uploadedFiles.length > 0 && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-4 space-y-2"
                          >
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium">Uploaded Files ({uploadedFiles.length})</h4>
                              <Badge variant="secondary">
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                Ready
                              </Badge>
                            </div>
                            {uploadedFiles.map((file, index) => (
                              <motion.div
                                key={index}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted/80 transition-colors"
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="w-4 h-4 text-purple-400" />
                                  <span className="text-sm font-medium">{file.name}</span>
                                  <Badge variant="outline" className="text-xs">
                                    {(file.size / 1024 / 1024).toFixed(1)} MB
                                  </Badge>
                                </div>
                                <motion.button
                                  whileHover={{ scale: 1.1 }}
                                  whileTap={{ scale: 0.9 }}
                                  onClick={() => setUploadedFiles((prev) => prev.filter((_, i) => i !== index))}
                                  className="p-1 hover:bg-destructive/20 rounded text-destructive"
                                >
                                  <X className="w-4 h-4" />
                                </motion.button>
                              </motion.div>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Enhanced Cloud Import */}
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Cloud className="w-5 h-5" />
                        Cloud Import
                        <Badge variant="secondary" className="ml-auto">
                          <Zap className="w-3 h-3 mr-1" />
                          Coming Soon
                        </Badge>
                      </CardTitle>
                      <CardDescription>Import documents directly from your cloud storage</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {[
                        { name: "Google Drive", icon: "📱", color: "bg-blue-500" },
                        { name: "Dropbox", icon: "📦", color: "bg-blue-600" },
                        { name: "OneDrive", icon: "☁️", color: "bg-blue-700" },
                      ].map((service, index) => (
                        <Tooltip key={service.name}>
                          <TooltipTrigger asChild>
                            <motion.div
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 }}
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              <Button
                                variant="outline"
                                className="w-full justify-start relative overflow-hidden group bg-transparent"
                              >
                                <span className="mr-3 text-lg">{service.icon}</span>
                                Connect to {service.name}
                                <motion.div
                                  className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity"
                                  initial={false}
                                />
                              </Button>
                            </motion.div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Connect to {service.name} (Coming Soon)</p>
                          </TooltipContent>
                        </Tooltip>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Enhanced Processing Actions */}
              <div className="grid md:grid-cols-2 gap-6">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                  <Card>
                    <CardHeader>
                      <CardTitle>Processing Options</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {[
                        {
                          label: "Auto-categorize documents",
                          defaultChecked: true,
                          description: "Automatically tag document types",
                        },
                        {
                          label: "Generate summaries",
                          defaultChecked: true,
                          description: "Create AI-powered summaries",
                        },
                        {
                          label: "Extract financial data",
                          defaultChecked: false,
                          description: "Focus on monetary values",
                        },
                      ].map((option, index) => (
                        <motion.div
                          key={option.label}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div>
                            <label className="text-sm font-medium">{option.label}</label>
                            <p className="text-xs text-muted-foreground">{option.description}</p>
                          </div>
                          <Switch defaultChecked={option.defaultChecked} />
                        </motion.div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
                  <Card>
                    <CardHeader>
                      <CardTitle>Processing Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                            <Button
                              className="w-full relative overflow-hidden group"
                              disabled={uploadedFiles.length === 0}
                              onClick={() => {
                                startProcessing()
                                setActiveTab("processing")
                              }}
                            >
                              <motion.div
                                className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 opacity-0 group-hover:opacity-100 transition-opacity"
                                initial={false}
                              />
                              <Play className="w-4 h-4 mr-2" />
                              Start AI Analysis ({uploadedFiles.length} files)
                              {uploadedFiles.length > 0 && (
                                <motion.div
                                  animate={{ rotate: 360 }}
                                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                                  className="ml-2"
                                >
                                  <Sparkles className="w-4 h-4" />
                                </motion.div>
                              )}
                            </Button>
                          </motion.div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Process all uploaded files with AI</p>
                        </TooltipContent>
                      </Tooltip>

                      <Tooltip>
                        <TooltipTrigger asChild>
                          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                            <Button variant="outline" className="w-full bg-transparent">
                              <Database className="w-4 h-4 mr-2" />
                              Import from Database
                            </Button>
                          </motion.div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Import documents from connected databases</p>
                        </TooltipContent>
                      </Tooltip>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>

            {/* Enhanced Processing Dashboard */}
            <TabsContent value="processing" className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                {/* Enhanced Document Preview */}
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-2">
                  <Card className="relative overflow-hidden">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="w-5 h-5" />
                        Document Preview
                        {isProcessing && (
                          <Badge variant="secondary" className="ml-auto">
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                            >
                              <RefreshCw className="w-3 h-3 mr-1" />
                            </motion.div>
                            Processing
                          </Badge>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-muted/50 rounded-lg p-8 text-center min-h-[400px] flex items-center justify-center relative overflow-hidden">
                        {isProcessing && (
                          <motion.div
                            className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-blue-500/5"
                            animate={{
                              background: [
                                "linear-gradient(45deg, rgba(147, 51, 234, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%)",
                                "linear-gradient(225deg, rgba(147, 51, 234, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%)",
                                "linear-gradient(45deg, rgba(147, 51, 234, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%)",
                              ],
                            }}
                            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                          />
                        )}
                        <div className="space-y-4 relative z-10">
                          <motion.div
                            animate={isProcessing ? { scale: [1, 1.1, 1] } : {}}
                            transition={{ duration: 2, repeat: isProcessing ? Number.POSITIVE_INFINITY : 0 }}
                          >
                            <FileText className="w-16 h-16 mx-auto text-muted-foreground" />
                          </motion.div>
                          <div>
                            <p className="font-medium">Invoice_2024_001.pdf</p>
                            <p className="text-sm text-muted-foreground">2.4 MB • Page 1 of 3</p>
                          </div>
                          {isProcessing && (
                            <motion.div className="space-y-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                              <motion.div
                                className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full mx-auto"
                                animate={{ rotate: 360 }}
                                transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                              />
                              <motion.p
                                className="text-sm text-purple-400"
                                animate={{ opacity: [0.5, 1, 0.5] }}
                                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                              >
                                Analyzing document with AI...
                              </motion.p>
                            </motion.div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Enhanced Processing Status */}
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                  <Card className="relative overflow-hidden">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Brain className="w-5 h-5" />
                        AI Processing Status
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {processingSteps.map((step, index) => (
                        <motion.div
                          key={step.name}
                          className="space-y-2"
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">{step.name}</span>
                            <motion.div
                              animate={step.status === "processing" ? { scale: [1, 1.2, 1] } : {}}
                              transition={{
                                duration: 1,
                                repeat: step.status === "processing" ? Number.POSITIVE_INFINITY : 0,
                              }}
                            >
                              {step.status === "completed" && <CheckCircle2 className="w-4 h-4 text-green-400" />}
                              {step.status === "processing" && (
                                <motion.div
                                  animate={{ rotate: 360 }}
                                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                                >
                                  <RefreshCw className="w-4 h-4 text-blue-400" />
                                </motion.div>
                              )}
                              {step.status === "pending" && <Clock className="w-4 h-4 text-muted-foreground" />}
                            </motion.div>
                          </div>
                          <Progress value={step.progress} className="h-2" />
                          <motion.p
                            className="text-xs text-muted-foreground"
                            animate={step.status === "processing" ? { opacity: [0.5, 1, 0.5] } : {}}
                            transition={{
                              duration: 2,
                              repeat: step.status === "processing" ? Number.POSITIVE_INFINITY : 0,
                            }}
                          >
                            {step.progress}% complete
                          </motion.p>
                        </motion.div>
                      ))}
                      {isProcessing && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                          <Button
                            variant="outline"
                            className="w-full bg-transparent"
                            onClick={() => setIsProcessing(false)}
                          >
                            <Pause className="w-4 h-4 mr-2" />
                            Pause Processing
                          </Button>
                        </motion.div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Enhanced Live Extraction Log */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                <Card className="relative overflow-hidden">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      Live AI Extraction Log
                      <Badge variant="secondary" className="ml-auto">
                        <motion.div
                          animate={{ opacity: [0.5, 1, 0.5] }}
                          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                        >
                          Real-time
                        </motion.div>
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-48">
                      <div className="space-y-2 font-mono text-sm">
                        <motion.div
                          className="text-green-400"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                        >
                          [OCR] Detected text regions: 47
                        </motion.div>
                        <motion.div
                          className="text-blue-400"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.5 }}
                        >
                          [NLP] Entity extraction: Invoice Number → INV-2024-001
                        </motion.div>
                        <motion.div
                          className="text-purple-400"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 1 }}
                        >
                          [NLP] Financial amount detected: $1,247.50
                        </motion.div>
                        <motion.div
                          className="text-yellow-400"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 1.5 }}
                        >
                          [NLP] Date parsing: March 15, 2024
                        </motion.div>
                        <motion.div
                          className="text-cyan-400"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 2 }}
                        >
                          [TAG] Document category: Invoice
                        </motion.div>
                        <motion.div
                          className="text-pink-400"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 2.5 }}
                        >
                          [TAG] Business context: Finance/Accounting
                        </motion.div>
                        {isProcessing && (
                          <motion.div
                            className="text-orange-400"
                            animate={{ opacity: [0.5, 1, 0.5] }}
                            transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
                          >
                            [PROCESS] Analyzing layout structure...
                          </motion.div>
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Results Panel - Enhanced with more animations */}
            <TabsContent value="results" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Enhanced Data View */}
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                  <Card className="relative overflow-hidden">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Database className="w-5 h-5" />
                        Extracted Data
                        <Badge variant="secondary" className="ml-auto">
                          <Award className="w-3 h-3 mr-1" />
                          {extractedData.length} Fields
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Field</TableHead>
                            <TableHead>Value</TableHead>
                            <TableHead>Confidence</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {mockExtractedData.map((item, index) => (
                            <motion.tr
                              key={index}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="hover:bg-muted/50 transition-colors"
                            >
                              <TableCell className="font-medium">
                                <div className="flex items-center gap-2">
                                  {item.field}
                                  <Badge variant="outline" className="text-xs">
                                    {item.type}
                                  </Badge>
                                </div>
                              </TableCell>
                              <TableCell className="font-mono">{item.value}</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Progress value={item.confidence} className="h-2 w-16" />
                                  <motion.span
                                    className="text-sm font-semibold"
                                    animate={{
                                      color:
                                        item.confidence > 95 ? "#22c55e" : item.confidence > 90 ? "#eab308" : "#ef4444",
                                    }}
                                  >
                                    {item.confidence}%
                                  </motion.span>
                                </div>
                              </TableCell>
                            </motion.tr>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Enhanced Tags & Summary */}
                <div className="space-y-6">
                  <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                    <Card className="relative overflow-hidden">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Tag className="w-5 h-5" />
                          Smart Tags
                          <motion.div
                            animate={{ rotate: [0, 360] }}
                            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                          >
                            <Sparkles className="w-4 h-4 text-purple-400" />
                          </motion.div>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2">
                          {["Invoice", "Finance", "Q1-2024", "TechCorp", "Payment Due", "Accounting"].map(
                            (tag, index) => (
                              <motion.div
                                key={tag}
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: index * 0.1 }}
                                whileHover={{ scale: 1.1 }}
                              >
                                <Badge variant="secondary" className="cursor-pointer hover:bg-purple-500/20">
                                  {tag}
                                </Badge>
                              </motion.div>
                            ),
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <Card className="relative overflow-hidden">
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-blue-500/5 opacity-0 hover:opacity-100 transition-opacity"
                        initial={false}
                      />
                      <CardHeader className="relative z-10">
                        <CardTitle className="flex items-center gap-2">
                          <Sparkles className="w-5 h-5" />
                          AI Summary
                          <motion.div
                            animate={{ y: [0, -2, 0] }}
                            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                          >
                            <Lightbulb className="w-4 h-4 text-yellow-400" />
                          </motion.div>
                        </CardTitle>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">Invoice</Badge>
                          <motion.div
                            animate={{ scale: [1, 1.05, 1] }}
                            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                          >
                            <Badge variant="outline" className="text-green-400 border-green-400">
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              98% Confidence
                            </Badge>
                          </motion.div>
                        </div>
                      </CardHeader>
                      <CardContent className="relative z-10">
                        <motion.p
                          className="text-sm leading-relaxed"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 0.5 }}
                        >
                          This is an invoice from TechCorp Solutions dated March 15, 2024, for services totaling
                          $1,247.50. The invoice number is INV-2024-001 and includes contact information for John Smith.
                          Payment terms indicate net 30 days with a due date of April 14, 2024.
                        </motion.p>
                      </CardContent>
                    </Card>
                  </motion.div>
                </div>
              </div>

              {/* Enhanced Export Options */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                <Card className="relative overflow-hidden">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Download className="w-5 h-5" />
                      Export & Integration Options
                      <Badge variant="secondary" className="ml-auto">
                        <Star className="w-3 h-3 mr-1" />3 Options
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                      {[
                        {
                          icon: <FileSpreadsheet className="w-6 h-6" />,
                          label: "Export to Excel",
                          color: "text-green-400",
                          desc: "Download as .xlsx",
                        },
                        {
                          icon: <Users className="w-6 h-6" />,
                          label: "Push to CRM",
                          color: "text-blue-400",
                          desc: "Sync with CRM system",
                        },
                        {
                          icon: <Database className="w-6 h-6" />,
                          label: "Save to Database",
                          color: "text-purple-400",
                          desc: "Store in database",
                        },
                      ].map((option, index) => (
                        <Tooltip key={option.label}>
                          <TooltipTrigger asChild>
                            <motion.div
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 }}
                              whileHover={{ scale: 1.05, y: -5 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <Button
                                variant={index === 0 ? "default" : "outline"}
                                className="flex flex-col items-center gap-2 h-auto py-6 relative overflow-hidden group"
                              >
                                <motion.div
                                  className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity"
                                  initial={false}
                                />
                                <div className={option.color}>{option.icon}</div>
                                <div className="text-center">
                                  <span className="font-medium">{option.label}</span>
                                  <p className="text-xs text-muted-foreground mt-1">{option.desc}</p>
                                </div>
                              </Button>
                            </motion.div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{option.desc}</p>
                          </TooltipContent>
                        </Tooltip>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* History Section - Enhanced */}
            <TabsContent value="history" className="space-y-6">
              {/* Enhanced Search & Filter */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="relative overflow-hidden">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Search className="w-5 h-5" />
                      Document History & Search
                      <Badge variant="secondary" className="ml-auto">
                        <History className="w-3 h-3 mr-1" />
                        {mockDocumentHistory.length} Documents
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-4 mb-6">
                      <motion.div className="flex-1" whileFocus={{ scale: 1.02 }}>
                        <Input
                          placeholder="Search documents by name, type, or content..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full"
                        />
                      </motion.div>
                      <motion.div whileHover={{ scale: 1.05 }}>
                        <Select>
                          <SelectTrigger className="w-48">
                            <SelectValue placeholder="Filter by type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Types</SelectItem>
                            <SelectItem value="invoice">Invoices</SelectItem>
                            <SelectItem value="resume">Resumes</SelectItem>
                            <SelectItem value="legal">Legal Documents</SelectItem>
                          </SelectContent>
                        </Select>
                      </motion.div>
                      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        <Button variant="outline">
                          <Filter className="w-4 h-4" />
                        </Button>
                      </motion.div>
                    </div>

                    <div className="rounded-lg border border-border/50 overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/50">
                            <TableHead>Document</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Accuracy</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {mockDocumentHistory.map((doc, index) => (
                            <motion.tr
                              key={doc.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="hover:bg-muted/30 transition-colors"
                              whileHover={{ backgroundColor: "rgba(147, 51, 234, 0.05)" }}
                            >
                              <TableCell className="font-medium">
                                <div className="flex items-center gap-2">
                                  <FileText className="w-4 h-4 text-purple-400" />
                                  {doc.name}
                                </div>
                              </TableCell>
                              <TableCell>
                                <motion.div whileHover={{ scale: 1.05 }}>
                                  <Badge variant="outline">{doc.type}</Badge>
                                </motion.div>
                              </TableCell>
                              <TableCell className="text-muted-foreground">{doc.date}</TableCell>
                              <TableCell>
                                <motion.div whileHover={{ scale: 1.05 }}>
                                  <Badge
                                    variant={doc.status === "Processed" ? "default" : "secondary"}
                                    className={doc.status === "Processing" ? "animate-pulse" : ""}
                                  >
                                    {doc.status === "Processing" && (
                                      <motion.div
                                        animate={{ rotate: 360 }}
                                        transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                                        className="w-3 h-3 mr-1"
                                      >
                                        <RefreshCw className="w-3 h-3" />
                                      </motion.div>
                                    )}
                                    {doc.status}
                                  </Badge>
                                </motion.div>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  {doc.accuracy > 0 && (
                                    <>
                                      <Progress value={doc.accuracy} className="h-2 w-12" />
                                      <span className="text-sm font-medium">{doc.accuracy}%</span>
                                    </>
                                  )}
                                  {doc.accuracy === 0 && <span className="text-muted-foreground">-</span>}
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="flex gap-2">
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                                        <Button size="sm" variant="outline">
                                          <Eye className="w-4 h-4" />
                                        </Button>
                                      </motion.div>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>View document</p>
                                    </TooltipContent>
                                  </Tooltip>

                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                                        <Button size="sm" variant="outline">
                                          <RefreshCw className="w-4 h-4" />
                                        </Button>
                                      </motion.div>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Re-analyze document</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </div>
                              </TableCell>
                            </motion.tr>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Settings Section - Enhanced */}
            <TabsContent value="settings" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Enhanced Custom Rules */}
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                  <Card className="relative overflow-hidden">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="w-5 h-5" />
                        Custom Extraction Rules
                        <motion.div
                          animate={{ rotate: [0, 10, -10, 0] }}
                          transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                        >
                          <Settings className="w-4 h-4 text-purple-400" />
                        </motion.div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <motion.div whileFocus={{ scale: 1.02 }}>
                        <label className="text-sm font-medium">Custom Keywords</label>
                        <Textarea
                          placeholder="Enter domain-specific keywords, one per line..."
                          rows={4}
                          className="mt-2"
                        />
                      </motion.div>
                      <motion.div whileFocus={{ scale: 1.02 }}>
                        <label className="text-sm font-medium">Category Mapping</label>
                        <Select>
                          <SelectTrigger className="mt-2">
                            <SelectValue placeholder="Select business category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="finance">Finance & Accounting</SelectItem>
                            <SelectItem value="hr">Human Resources</SelectItem>
                            <SelectItem value="legal">Legal & Compliance</SelectItem>
                          </SelectContent>
                        </Select>
                      </motion.div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Enhanced Integration Settings */}
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Globe className="w-5 h-5" />
                        Integration Settings
                        <Badge variant="secondary" className="ml-auto">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          2/3 Connected
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {[
                        {
                          name: "Excel Template",
                          status: "Connected",
                          icon: <FileSpreadsheet className="w-4 h-4" />,
                          color: "text-green-400",
                        },
                        {
                          name: "CRM API Key",
                          status: "Not Set",
                          icon: <Users className="w-4 h-4" />,
                          color: "text-gray-400",
                        },
                        {
                          name: "Database Connection",
                          status: "Connected",
                          icon: <Database className="w-4 h-4" />,
                          color: "text-green-400",
                        },
                      ].map((integration, index) => (
                        <motion.div
                          key={integration.name}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                          whileHover={{ scale: 1.02 }}
                        >
                          <div className="flex items-center gap-3">
                            <div className={integration.color}>{integration.icon}</div>
                            <div>
                              <span className="font-medium">{integration.name}</span>
                              <p className="text-xs text-muted-foreground">
                                {integration.status === "Connected" ? "Active integration" : "Setup required"}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <motion.div
                              animate={integration.status === "Connected" ? { scale: [1, 1.1, 1] } : {}}
                              transition={{
                                duration: 2,
                                repeat: integration.status === "Connected" ? Number.POSITIVE_INFINITY : 0,
                              }}
                            >
                              <Badge variant={integration.status === "Connected" ? "default" : "secondary"}>
                                {integration.status === "Connected" && <CheckCircle2 className="w-3 h-3 mr-1" />}
                                {integration.status}
                              </Badge>
                            </motion.div>
                            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                              <Button size="sm" variant="outline">
                                Configure
                              </Button>
                            </motion.div>
                          </div>
                        </motion.div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Enhanced User Management */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Users className="w-5 h-5" />
                        User Management & Permissions
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {[
                        {
                          label: "Admin Access",
                          description: "Full system access and configuration",
                          defaultChecked: true,
                        },
                        {
                          label: "Bulk Processing",
                          description: "Allow batch uploads and processing",
                          defaultChecked: true,
                        },
                        { label: "API Access", description: "Enable developer API endpoints", defaultChecked: false },
                      ].map((option, index) => (
                        <motion.div
                          key={option.label}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div>
                            <p className="font-medium">{option.label}</p>
                            <p className="text-sm text-muted-foreground">{option.description}</p>
                          </div>
                          <Switch defaultChecked={option.defaultChecked} />
                        </motion.div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Enhanced Security Settings */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
                  <Card className="relative overflow-hidden">
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-green-500/5 to-emerald-500/5 opacity-0 hover:opacity-100 transition-opacity"
                      initial={false}
                    />
                    <CardHeader className="relative z-10">
                      <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5" />
                        Security & Privacy
                        <motion.div
                          animate={{ rotate: [0, 360] }}
                          transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                        >
                          <Shield className="w-4 h-4 text-green-400" />
                        </motion.div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 relative z-10">
                      {[
                        {
                          label: "Data Encryption",
                          description: "Encrypt all uploaded documents",
                          defaultChecked: true,
                        },
                        { label: "Auto-Delete", description: "Remove files after 30 days", defaultChecked: false },
                      ].map((option, index) => (
                        <motion.div
                          key={option.label}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div>
                            <p className="font-medium">{option.label}</p>
                            <p className="text-sm text-muted-foreground">{option.description}</p>
                          </div>
                          <Switch defaultChecked={option.defaultChecked} />
                        </motion.div>
                      ))}
                      <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                        <Button variant="outline" className="w-full bg-transparent">
                          <Download className="w-4 h-4 mr-2" />
                          Export All Data
                        </Button>
                      </motion.div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Help Panel */}
        <AnimatePresence>
          {showHelpPanel && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
              onClick={() => setShowHelpPanel(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-card rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto border border-border/50"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
                      <HelpCircle className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold">XeveDoc Help Center</h3>
                      <p className="text-sm text-muted-foreground">Get help and learn about features</p>
                    </div>
                  </div>
                  <Button variant="ghost" onClick={() => setShowHelpPanel(false)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="space-y-4">
                  {[
                    {
                      title: "Getting Started",
                      description: "Learn the basics of document analysis",
                      icon: <BookOpen className="w-5 h-5" />,
                    },
                    {
                      title: "Upload Documents",
                      description: "How to upload and prepare your files",
                      icon: <Upload className="w-5 h-5" />,
                    },
                    {
                      title: "AI Processing",
                      description: "Understanding OCR and NLP analysis",
                      icon: <Brain className="w-5 h-5" />,
                    },
                    {
                      title: "Export & Integration",
                      description: "Export data and connect to other tools",
                      icon: <Download className="w-5 h-5" />,
                    },
                  ].map((item, index) => (
                    <motion.div
                      key={item.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 rounded-lg border border-border/50 hover:border-purple-500/50 cursor-pointer transition-colors"
                      whileHover={{ scale: 1.02 }}
                    >
                      <div className="flex items-center gap-3">
                        <div className="text-purple-400">{item.icon}</div>
                        <div>
                          <h4 className="font-medium">{item.title}</h4>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-6 pt-4 border-t border-border/50 text-center">
                  <Button onClick={startTutorial} variant="outline">
                    <Play className="w-4 h-4 mr-2" />
                    Restart Tutorial
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </TooltipProvider>
  )
}
